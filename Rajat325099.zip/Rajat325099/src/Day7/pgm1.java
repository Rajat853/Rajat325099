package Day7;


public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Animal a=new Animal();
		Elephant e1= new Elephant("Raju","Black",20,400);
		Elephant e2= new Elephant("Mak","Black",14,300);
		e1.display();
		e2.display();
	}

}
