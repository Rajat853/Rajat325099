package Day7;

public class Tiger {
String loc;

}
