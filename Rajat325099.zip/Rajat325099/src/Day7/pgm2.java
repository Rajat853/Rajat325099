package Day7;
import java.io.*;
import java.util.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY3.Student;


public class pgm2 {

	public ArrayList<Student> read_Excel(){
	
		ArrayList<Student> std_al = new ArrayList<Student>();
		
		
		for(int i=1;i<=2;i++) {
			Student s=new Student();
		try {
			
			File f = new File("C:\\Users\\rajat.kumar2\\Book1.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow r = sh.getRow(i);
					
			XSSFCell c = r.getCell(0);
			s.rollno  = (int)c.getNumericCellValue();
			
			XSSFCell c1 = r.getCell(1);
			s.name= c1.getStringCellValue();
			
			XSSFCell c2= r.getCell(2);
			s.jav=(int)c2.getNumericCellValue();
			
			XSSFCell c3=r.getCell(3);
			s.sel=(int)c3.getNumericCellValue();
		
			s.average();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		std_al.add(s);
		
		}
		
		return std_al;
	}
	
	
	public void write_Excel(ArrayList<Student> stal) {
		
		try {
		File f = new File("C:\\Users\\rajat.kumar2\\Book1.xlsx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		int row=1;
		
		for(Student st : stal) {
		XSSFRow r = sh.getRow(row);
		XSSFCell c = r.createCell(4);
		c.setCellValue(st.avg);
		row++;
		
		}

		FileOutputStream fos = new FileOutputStream(f);
		wb.write(fos);
		}
		
		catch(Exception e) {
			e.printStackTrace();
		
	}
		
	}
	
	
}
