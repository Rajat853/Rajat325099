package Day7;

import java.util.ArrayList;

import DAY3.Student;
public class pgm3 {

	  Student stu = new Student();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm2 p = new pgm2();
		ArrayList<Student> as = new ArrayList<Student>();
		as=p.read_Excel();
		p.write_Excel(as);
		
		
	}

}
