package Day7;

public class Animal {

	String name;
	String color;
	int age;
	int weight;
Animal(){
	
}
	Animal(String name,String color,int age,int weight){
		this.name=name;
		this.color=color;
		this.age=age;
		this.weight=weight;		
	}
	
	
	public void walk() {
		System.out.println("Animals walk");
	}
	
	
}
