package Day7;


public class Elephant extends Animal{
	int lot;
    int lotusk;
	
    Elephant(int lot,int lotusk){
    	this.lot=lot;
    	this.lotusk=lotusk;
    }
    
    public void herbivorous() {
    	System.out.println("Elephants eat plants");
    }

    public void display() {
//    	System.out.println("Elephant Details "+"Name : "+this.name);
//    	System.out.println("Color of the elephant : "+this.color);
//    	System.out.println("Age of the elephant : "+ this.age);
//    	System.out.println("Weight of the elephant : "+this.weight);
    	System.out.println("Length of Trunk the elephant : "+lot);
    	System.out.println("Length of Tusk the elephant : "+lotusk);
    			           
    }

}
