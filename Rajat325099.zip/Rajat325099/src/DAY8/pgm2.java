package DAY8;
import java.util.*;
public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Integer> all=new ArrayList<Integer>();
		pgm1 p=new pgm1();
		all=p.read_excel();
		p.write_Excel(all); 
		
	}

}
