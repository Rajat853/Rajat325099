package DAY8;

import java.io.*;
import java.util.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class pgm1 {

	
	public ArrayList<Integer>read_excel() {
	
		ArrayList<Integer>  ali=new ArrayList<Integer>();
		
		for(int i=1;i<=4;i++) {
			Passenger p=new Passenger();
		try {		
	
		File f=new File("C:\\Users\\rajat.kumar2\\Book1.xlsx");
	FileInputStream fis=new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet2");
	
	XSSFRow r=sh.getRow(i);
	
	XSSFCell c=r.getCell(0);
	p.sn=(int)c.getNumericCellValue();
	
	XSSFCell c1=r.getCell(1);
	p.name=c1.getStringCellValue();
	
	XSSFCell c2=r.getCell(2);
	p.from=c2.getStringCellValue();
	
	XSSFCell c3=r.getCell(3);
	p.to=c3.getStringCellValue();
	
	XSSFCell c4=r.getCell(4);
	p.rate=(int)c4.getNumericCellValue();
	
	XSSFCell c5=r.getCell(5);
	p.seats=(int)c5.getNumericCellValue();
	
	p.result();
	ali.add(p.total);
	
	}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
		return ali;
		
	}
	
	
	
	public void write_Excel(ArrayList<Integer> al) {
		
		try {
		File f=new File("C:\\Users\\rajat.kumar2\\Book1.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet2");
		
		int row=1;
		
		for(Integer in:al) {
			XSSFRow r=sh.getRow(row);
			XSSFCell c=r.createCell(6);
			c.setCellValue(in);
			row++;	
		}
		
		FileOutputStream  fos=new FileOutputStream(f);
		wb.write(fos);
		
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
}
