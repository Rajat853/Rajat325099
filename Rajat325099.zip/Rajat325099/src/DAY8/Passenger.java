package DAY8;

public class Passenger {

	int sn;
	String name;
	String from;
	String to;
	int rate=50;
	int seats=2;
    int total;
    
    public void result() {
    	total=rate*seats;
    }
}
