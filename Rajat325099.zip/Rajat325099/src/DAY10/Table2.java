package DAY10;

public class Table2 {
int cid;
String cName;

}
