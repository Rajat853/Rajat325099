package DAY10;

public class MainCls {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Operation op=new Operation();
		
		op.read1();
		op.read2();
		op.read3();
		op.serach2();
		
	}

}
