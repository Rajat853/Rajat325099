package DAY10;
public class Table4 {
int cid;
String cName;
String from;
String to;
int uPrice;
int not;
int price;

}
