package DAY10;
public class Table3 {
int cid;
int rid;
int not;

	
}
