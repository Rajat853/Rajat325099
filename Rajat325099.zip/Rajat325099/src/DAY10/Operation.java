package DAY10;
import java.io.*;
import java.util.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Operation {
	ArrayList<Table1>  al1=new ArrayList<Table1>();
	ArrayList<Table2>  al2 = new ArrayList<Table2>();
	ArrayList<Table3>  al3=new ArrayList<Table3>();
	ArrayList<Table4>  al4=new ArrayList<Table4>();

	public void read1() {
		
		for(int i=1;i<=2;i++) {
			Table1 t1=new Table1();
		try {		
	
		File f=new File("C:\\Users\\rajat.kumar2\\Desktop\\Excel File\\Table1.xlsx");
	FileInputStream fis=new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet1");
	
	XSSFRow r=sh.getRow(i);
	
	XSSFCell c=r.getCell(0);
	t1.route_id=(int)c.getNumericCellValue();
	
	XSSFCell c1=r.getCell(1);
	t1.from =c1.getStringCellValue();
	
	XSSFCell c2=r.getCell(2);
	t1.to =c2.getStringCellValue();
	
	XSSFCell c3=r.getCell(3);
	t1.price=(int)c3.getNumericCellValue();
	
	
	al1.add(t1);
	
	}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
		
	}
	
    public void read2() { 
		
		for(int i=1;i<=2;i++) {
			Table2 t2=new Table2();
		try {		
	
		File f=new File("C:\\Users\\rajat.kumar2\\Desktop\\Excel File\\Table2.xlsx");
	FileInputStream fis=new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet1");
	
	XSSFRow r=sh.getRow(i);
	
	XSSFCell c=r.getCell(0);
	t2.cid = (int)c.getNumericCellValue();
	
	
	XSSFCell c1=r.getCell(1);
	t2.cName = c1.getStringCellValue();
	
	
	al2.add(t2);
	
	}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
		
		
	}

    
    
public void read3() { 
		
		for(int i=1;i<=2;i++) {
			Table3 t3=new Table3();
		try {		
	
		File f=new File("C:\\Users\\rajat.kumar2\\Desktop\\Excel File\\Table3.xlsx");
	FileInputStream fis=new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet1");
	
	XSSFRow r=sh.getRow(i);
	
	XSSFCell c=r.getCell(0);
	 t3.cid = (int)c.getNumericCellValue();
	
	
	XSSFCell c1=r.getCell(1);
	t3.rid = (int)c.getNumericCellValue();
	
	XSSFCell c2=r.getCell(2);
	t3.not = (int)c.getNumericCellValue();
	
	al3.add(t3);
	
	}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
		
	}
    

    public void serach2() {
    	int index=0,r=1;
    	for(int i=1;i<=2;i++) {
    		Table3 t3=new Table3();
    		t3=al3.get(index);
    	   Table2 t2=new Table2();
    		int j=0;
    		boolean val=false;
    		
    		while(j<al2.size()) {
    			t2=al2.get(j);
    			if(t3.cid==t2.cid)
    			{
    				val=true;
    				break;
    			}
    			j++;
    		}
    		if(val)
    	write(r,index);
    	r++;
    	index++;
    	}
    	
    }
    
    public void write(int row,int in) {
    	
    	int ind=0;
    	try {
    		Table1 t1=al1.get(ind);
    				Table2 t2=al2.get(ind);
    				Table3 t3=al3.get(ind);
    				
    		
    		File f=new File("C:\\Users\\rajat.kumar2\\Desktop\\Excel File\\Table4.xlsx");
    		FileInputStream fis=new FileInputStream(f);
    		XSSFWorkbook wb=new XSSFWorkbook(fis);
    		XSSFSheet sh=wb.getSheet("Sheet1");
    	
    		XSSFRow r=sh.createRow(row);
    		
    		XSSFCell c=r.createCell(0);
    		c.setCellValue(t2.cid);
    		
    		XSSFCell c1=r.createCell(1);
    		c1.setCellValue(t2.cName);
    		
    		XSSFCell c2=r.createCell(2);
    		c2.setCellValue(t1.from);
    		
    		XSSFCell c3=r.createCell(3);
    		c3.setCellValue(t1.to);
    		
    		XSSFCell c4=r.createCell(4);
    		c4.setCellValue(t1.price);
    		
    		XSSFCell c5=r.createCell(5);
    		c5.setCellValue(t3.not);
    		
    		XSSFCell c6=r.createCell(6);
    		int p=t1.price*t3.not;
    		c6.setCellValue(p);
    		
    		FileOutputStream fos=new FileOutputStream(f);
    		wb.write(fos);
    		ind++;
    	}
    	
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    }

    
	
}
