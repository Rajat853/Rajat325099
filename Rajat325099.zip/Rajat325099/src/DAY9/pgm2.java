package DAY9;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

       pgm1 p=new pgm1();
		
		p.setAccount_bal(1000);
		p.setAccount_no(12);
		
		System.out.println("Account Number : "+ p.getAccount_no()
		                   +" , Account Balance : "+ p.getAccount_bal());
	}

}
