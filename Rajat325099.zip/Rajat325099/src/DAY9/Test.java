package DAY9;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Bank b;
		b=new Citi();
		System.out.println("Citi : "+b.roi());
		
		b=new Yes();
		System.out.println("Yes : "+b.roi());
		
	}

}
