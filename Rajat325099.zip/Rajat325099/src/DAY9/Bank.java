package DAY9;

public class Bank {

	public float roi() {
		return 0f;
	}
}
