package DAY9;

public class Yes extends Bank{

	public float roi() {
		return 6f;
	}
}
