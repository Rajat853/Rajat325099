package DAY9;

public class Citi extends Bank {

	public float roi() {
		return 4.5f;
	}
	
}
