package DAY6;

import java.util.ArrayList;

import DAY4.Student2;

public class pgm3 {

	ArrayList<Student2> as=new ArrayList<Student2>();
	public void create()
	{
		Student2 s1=new Student2("Rajat",1,45,99);
		Student2 s2=new Student2("Shubham",2,78,87);
		
		as.add(s1);
		as.add(s2);
	}
	
	public void display() {
		for(Student2 s:as) {
		
			System.out.println("Name : "+s.name 
					+"Rollno : "+s.rollno
					+"Sel : "+s.sel
					+"Jav : "+s.jav
					+"Average : "+s.avg);	
		}

		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		pgm3 p=new pgm3();
		p.create();
		p.display();
	
		
		
		
	}

}
