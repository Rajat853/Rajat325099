package DAY6;
import java.util.*;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> al=new ArrayList<String>();
	
		al.add("Rajat");
		al.add("Kumar");
		System.out.println(al);
		

	}

}
