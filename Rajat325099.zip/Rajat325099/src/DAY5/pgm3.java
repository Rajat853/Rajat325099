.package DAY5;

import java.io.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY3.Student;

public class pgm3 {
	
	public Student readExcel(int n) {
		Student s = new Student();

		try {
		File f = new File("C:\\Users\\rajat.kumar2\\Book1.xlsx");
		FileInputStream fis= new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		XSSFRow r = sh.getRow(n);

		    XSSFCell c = r.getCell(0);
		            s.rollno = (int) c.getNumericCellValue();  
		            
		            XSSFCell c1 = r.getCell(1);
		            s.name = c1.getStringCellValue();
		           
		            XSSFCell c2 = r.getCell(2);
		            s.m1 = (int) c2.getNumericCellValue();
		           
		            XSSFCell c3 = r.getCell(3);
		            s.m2 = (int)c3.getNumericCellValue();

		}
		catch(Exception e) {
		e.printStackTrace();
		}
		return s;

		}

	public void writeExcel(Student s1,int n) {

	try {
	File f = new File("C:\\Users\\rajat.kumar2\\Book1.xlsx");
	FileInputStream fis= new FileInputStream(f);
	XSSFWorkbook wb = new XSSFWorkbook(fis);
	XSSFSheet sh = wb.getSheet("Sheet1");
	XSSFRow r = sh.getRow(n);
	XSSFCell c = r.createCell(4);
	c.setCellValue((double) s1.avg);

	FileOutputStream fos = new FileOutputStream(f);
	wb.write(fos);


	}catch(Exception e) {
	e.printStackTrace();
	}
	}
	

}
