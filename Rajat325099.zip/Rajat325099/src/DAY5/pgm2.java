package DAY5;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int num[]= {1,2,4};
			int b=num[2];
			System.out.println(b);
			
			int a=10,g=0,c;
			c=a/g;
			System.out.println(c);
			
		}
		catch(ArithmeticException e) {
			System.out.println("in arithmetic exception block");
		}
		catch(ArrayIndexOutOfBoundsException es) {
			System.out.println("inside array index out of bounds exception");
			
		}
		System.out.println("out of catch block");



	}

}
