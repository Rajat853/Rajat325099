package DAY4;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		pgm4 pg=new pgm4();
		System.out.println(pg.add(12, 13f));
		System.out.println(pg.add(12, 11));
	}

}
