package DAY4;

public class Student2 {

	public String name="Rajat";
	public int rollno;
	public int sel;
	public int jav;
   public float avg;
    
    public void average() {
    	this.avg=(this.sel+this.jav)/2;
    	//return avg;
    }
	
   public Student2(String name,int rollno,int sel,int jav){
      this.name=name;
      this.rollno=rollno;
      this.sel=sel;
      this.jav=jav;
      average();
    }
}
