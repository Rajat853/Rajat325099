package DAY4;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int cmax=4;
		for(int r=1;r<=3;r++) {
			
			for(int c=1;c<=cmax;c++) {
				System.out.print(" ");
			}
			for(int d=1;d<=r;d++)
			{
				System.out.print(1);
			for(int s=r;s<=r;s++)
				System.out.print(" ");
			}
		 
			System.out.println();
			 cmax=cmax-2;
		}
		
		
		
	}

}
