package DAY4;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="i am working in global logic";
		int count=0;
		
		//Counting number of character
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)!=' ') {
				count++;
			}
		}

		
		char ar[]=new char[count];
		
		//Adding all characters to the array
		
		int n=0;
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)!=' '){
			ar[n++]=str.charAt(i);
		}
		}
			
		//Counting unique number of character
		int unique=0;
		for(int i=0;i<ar.length;i++) {
			boolean val=true;
			int j=i-1;
			while(j>=0) {
				if(ar[i]==ar[j]) {
				
					val=false;
					break;
				}
				j--;
				
			}
			if(val)
				unique++;
		}

		char uni[]=new char[unique];
		//Adding unique character to the array
		int push=0;
		for(int i=0;i<ar.length;i++) {
			boolean val=true;
			int j=i-1;
			while(j>=0) {
				if(ar[i]==ar[j]) {
					val=false;
					break;
				}
				j--;
				
			}
			if(val)
				uni[push++]=ar[i];
		}
		
		
		//Counting occurrence of each unique character
		for(int i=0;i<ar.length;i++) 
			System.out.print(ar[i]+" ");
		
		System.out.println();
		
		
		for(int i=0;i<uni.length;i++) {
			int test=0;
			
			for(int j=0;j<ar.length;j++) {
				if(uni[i]==ar[j])
					test++;
			}
			
			System.out.println(uni[i]+" : "+test);
			
		}
		
		
		
	}

}
