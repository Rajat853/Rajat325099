package DAY4;

public class pgm4 {

	public int add(int x,int y) {
		return x+y;
	}

	
	
	public float add(int x,float y) {
		return x+y;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
