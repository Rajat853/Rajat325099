package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="I am working with Global Logic in Noida";
		int index=0;
		String arr[]=new String[8];
		int i=0,a=0;
		
		
			while((index=str.indexOf(' ',index+1))>0) {
                arr[i]=str.substring(a,index);
                a=index+1;
				i++;
		}
			
			arr[i]=str.substring(a,str.length());
			
	for(String out:arr)
		System.out.println(out);
	}

}
